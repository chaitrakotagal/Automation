package com.Woolies.Chaitra;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomeObject {

	public WebDriver driver;
	public WebDriverWait waitDriver;
	
	By searchbox=By.xpath("//input[@id='gh-ac']");
	By searchbtn=By.xpath("//*[@id='gh-btn']");
	By varperfume=By.xpath("//li[@id='srp-river-results-listing1']/div/div[1]");
	By addtocart=By.xpath("//*[@id='atcRedesignId_btn']");
	By gotocart=By.xpath("//*[@id='atcRedesignId_overlay-atc-container']/div/div[1]//div[2]/a[2]");

	
	public HomeObject(WebDriver driver) 
	{	
		this.driver=driver;
		waitDriver = new WebDriverWait(driver,15);	
	}

	public WebElement getSearchbox()
	{
		return driver.findElement(searchbox);
	}
	
	public WebElement getSerachbtn()
	{
		return driver.findElement(searchbtn);
	}
	
	public WebElement getPerfume()
	{
		return driver.findElement(varperfume);
	}
	
	public WebElement Addtocart()
	{
		waitDriver.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(addtocart));
		
		return driver.findElement(addtocart);
	}
	
	public WebElement Gotocart()
	{
		return driver.findElement(gotocart);
	}
	
}
