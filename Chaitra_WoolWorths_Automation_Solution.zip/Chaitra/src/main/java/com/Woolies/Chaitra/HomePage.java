package com.Woolies.Chaitra;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class HomePage extends base {
	
	@Test
	public void selectPerfume() throws IOException, InterruptedException
	{
		
		driver=initializeDriver();
		HomeObject homeobj=new HomeObject(driver);
		homeobj.getSearchbox().click();
		homeobj.getSearchbox().sendKeys("perfume");
		homeobj.getSerachbtn().click();
		homeobj.getPerfume().click();
		homeobj.Addtocart().click();
		
		if (homeobj.Gotocart().isDisplayed()) 
		{
			homeobj.Gotocart().click();
		}
		
		driver.quit();
	}
	
	
	
	

}
